janrain.settings.capture.flowName = 'plugins';
janrain.settings.capture.modalCloseHtml = '';
janrain.settings.capture.screenToRender = 'resetPasswordRequestCode';

function janrainCaptureWidgetOnLoad() {
    janrain.capture.ui.start();
}

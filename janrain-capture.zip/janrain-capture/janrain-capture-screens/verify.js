function janrainCaptureWidgetOnLoad() {
    janrain.capture.ui.start();
}

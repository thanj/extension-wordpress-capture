

    /* Edit Below - begin custom (and override) settings */
    
    // janrain.settings.capture.confirmModalClose = true;
    
    // janrain.settings.capture.flowVersion = "HEAD";
    // janrain.settings.capture.modalCloseHtml = '<span class="janrain-icon-16 janrain-icon-ex"></span>';
    
    /* Edit Above - end custom (and override) settings */
 
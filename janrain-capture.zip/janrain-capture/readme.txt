=== Janrain Capture ===
Contributors: bhamrick, rwright, jeremyjanrain
Tags: capture, janrain, sso
Requires at least: 3.0
Tested up to: 3.1
License: APL

Social User Registration and Profile Storage with Janrain Capture

== Description ==

Janrain Capture provides hosted registration and authentication with social identity providers including Facebook, Google, Yahoo!, OpenID, LinkedIn, eBay, Twitter and many others or through traditional form field methods. Capture also includes a cloud-hosted registration and authentication system that allows site owners to maintain a central repository for user information, that can be deployed on one or more web sites.  Automatically store social profile data from social login and registration, site-specific data, off-line and 3rd-party data, as well as legacy data. Build a unified view on users by uniting this user information, normally distributed across disparate databases, mobile sites and apps, web properties and vendor systems such as email marketing, subscription billing or CRM to build a 360 degree view of users.
This module greatly accelerates the time required to implement Janrain Capture into your WordPress web sites, helping to improve your registration conversion rates by allowing your customers to register and sign-in using their prefered identities.
Janrain Capture’s registration and social profile database features include:

**Social login and registration**
In a study conducted by Blue research, Janrain found that 86% of users are very likely to leave a site when prompted to create a new traditional account (username and password). Janrain Capture eliminates the need for a new username and password by authenticating users with existing 3rd party and social identities like Facebook, Google, Yahoo!, LinkedIn, Twitter, etc. Janrain also found that 42% of users prefer to use Facebook for social registration. However, with support for more than 20 identity providers, customers can meet the needs of the remain 58% of new users.
**Pre-populated forms**
88% of users admit to providing false registration info. Capture seamlessly pre-fills registration fields to streamline registration for users and provide customers with highly accurate, rich social profile data.
**Traditional account support and mapping**
Capture supports existing accounts with side-by-side social and traditional logins as well as the option for customers to offer traditional accounts to new users. Account mapping allows users to map a 3rd party identity to their legacy account resulting in a one-click return login experience for users and rich social profile data for customers.
**Personalized, one-click return experience**
Capture personalizes and simplifies the user’s return experience by welcoming the user back by name and prompting them to login with their previously chosen identity provider for a one-click return login.
**Email verification and in-line form field validation**
Capture features an email verification flow to ensure that all user profiles contain an active email account. In-line form field validation further improves the quality of user profile data with field format rules and unique username availability and suggestions.
**Rich customization options**
Capture registration enables customers to match registration screens to their site’s look and feel via CSS and API. Registration forms can configured to collect any definable field for storage in the Capture database and with conditional, progressive, and multi-forms, users see highly relevant registration screens based on user origin, activity, site, etc.
**Self-service account management**
Capture provides users and customers alike with reliable, self-service features for password reset and account deactivation or deletion. In addition, users can access a profile management form to add additional identity providers, update their user profile, or change their on-site privacy settings.

=Advanced Registration Features=
In addition, Capture supports websites with advanced features for sites and users:
* TOS acceptance or subscription opt-in
* CAPTCHA verification
* Dirty word filter
* Mobile optimizations and SDKs for native applications
* Event hooks for 3rd party analytics

[About Janrain Capture](http://janrain.com/products/capture/)

For technical documentation please refer to
(http://developers.janrain.com/documentation/capture/)[http://developers.janrain.com/documentation/capture/]

== Installation ==
Install through the Administration Panel or extract plugin archive in your plugin directory.

Once installed, visit the Janrain Capture menu item in the Administration Panel to enter your Janrain Capture configuration details. At a minimum, you will need to enter an Application Domain, API Client ID, and API Client Secret.

To insert Capture links in posts or pages you can use the shortcode: [janrain_capture]

By default, [janrain_capture] will result in a link with the text "Sign in / Register" that will launch a modal window pointing to your Capture signin screen. You can customize the text, action, and starting width/height of the modal window by passing in additional attributes. The following is an example of a link to the legacy_register screen with a height of 800px and a width of 600px:

[janrain_capture text="Register" action="legacy_register" width="600" height="800"]

You can prevent the construction of the link and simply return the URL to the screen by adding the attribute href_only="true" to the shortcode.

To insert links in your theme templates you can use the [do_shortcode](http://codex.wordpress.org/Function_Reference/do_shortcode) WordPress function.

As of version 0.0.4 this plugin now supports Engage Social Sharing via the Engage app configured for Capture. To use this feature, ensure 'Enable Social Sharing' is checked in the UI Options administration page and use the [janrain_share] shortcode. If the $post object is available the title, description, URL, and the most recent attached image URL will automatically be determined for sharing. These variables, as well as the button text, can be overridden with the following shortcode attributes:

* title
* description
* url
* img
* text

Example:
[janrain_share title="Janrain Engage Share Widget" description="Instructions for how to configure the Janrain Engage Share Widget" url="wordpress.org/extend/plugins/janrain-capture/" text="Tell a friend"]

== Multisite Installation ==
This plugin now fully supports WordPress Multisite. To install proceed as above, however you must Network Enable this plugin. The Janrain Capture administration menu will appear on the Network Admin dashboard.

Individual blogs can be updated with separate UI settings and a different API Client ID through the Janrain Capture administration menu in each blog's dashboard. If no changes are made they will default to the network admin settings.
